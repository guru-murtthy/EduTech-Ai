# EduTech AI - Your Personal AI Learning Mentor

EduTech AI is a complete production-style MVP personalize learning platform designed to act as a digital mentor for students. Built for **SDG 4: Quality Education**, it dynamically adapts curriculum roadmaps, recommends structured resources, generates interactive quizzes, predicts performance scores using Random Forest classifiers, and features an interactive **Algorithmic Simulation Lab** focused on the **Decrease-and-Conquer (Binary Search)** case study.

---

## 🚀 Tech Stack

* **Frontend**: Next.js 15 (App Router), React, TypeScript, Tailwind CSS, Lucide Icons
* **Backend**: Spring Boot 3, Java 21, Spring Security + stateless JWT auth, Hibernate/JPA
* **AI Layer**: Python 3.13 FastAPI, scikit-learn, LangChain / OpenAI API (with robust offline mocks)
* **Database**: PostgreSQL (Docker profile) / H2 File database (local dev profile)
* **Deployment**: Docker & Docker Compose / Local startup scripts

---

## 📂 Project Structure

```
Edutech/
├── backend/            # Spring Boot REST API
│   ├── src/main/java/com/edutech/
│   │   ├── config/     # Security, JWT filters, AI RestTemplate client
│   │   ├── controller/ # REST Controllers
│   │   ├── model/      # Database JPA Entities
│   │   └── repository/ # Spring Data JpaRepositories
│   ├── pom.xml         # Maven dependencies
│   └── Dockerfile
├── ai-service/         # FastAPI Python AI Service
│   ├── main.py         # REST controllers & fallback logic
│   ├── model.py        # Random Forest model training & prediction
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/           # Next.js 15 Portal
│   ├── src/app/        # Login, Onboarding survey, Dashboards, Lab
│   ├── src/lib/        # Client API request wrapper
│   └── Dockerfile
├── docker-compose.yml  # Orchestrates PostgreSQL + 3 services
└── run-dev.bat         # Single-click Windows local runner
```

---

## ⚙️ Quick Start (Local Running Guide)

To execute the entire stack on your local Windows system, you can use either Docker or the direct native starter:

### Method A: Single-Click Native Script (Recommended)
This method is perfect if you do not have Docker active:
1. Double-click the file `run-dev.bat` located in the project root folder.
2. The script will automatically trigger three cmd windows running dependencies installation and startup:
   * **FastAPI Service**: Starts on `http://localhost:8000`
   * **Spring Boot API**: Starts on `http://localhost:8080` (utilizing automatically created H2 database `./data/edutechdb`)
   * **Next.js Portal**: Starts on `http://localhost:3000`
3. Wait 10-15 seconds for Maven and Next.js compilation, then open your browser at **`http://localhost:3000`**.

### Method B: Docker Compose
If Docker is active on your system, launch all services by executing:
```bash
docker-compose up --build
```
This boots up PostgreSQL on `5432` alongside the other services.

---

## 🎯 Demystifying the SDG 4 Algorithmic Case Study

### Case Study: Adaptive Learning Resource Recommendation
Large-scale learning networks store millions of educational resources. To ensure students obtain custom matched content rapidly, indexing arrays must be searched efficiently.

#### 1. Algorithmic Techniques Compared:
* **Linear Search**: Scans elements sequentially. Worst-case complexity of $O(N)$ (e.g. up to 1,000,000 checks for a library of 1 million articles).
* **Binary Search (Decrease-and-Conquer)**: Relies on pre-sorting. Divides the remaining search bounds by half at each step. Worst-case complexity of $O(\log N)$ (e.g. up to 20 checks for a library of 1 million articles).

#### 2. Interactive Algorithmic Lab:
Located at `/dashboard/lab`, students run step-by-step visualizations of these searches. They observe index indices shrinking in real-time, inspect comparison counters, and write complexity worksheets graded dynamically by our digital mentor model.

---

## 🎙️ Hackathon Presentation Material

### 1. Pitch Deck Outline
* **Slide 1: Title & SDG 4 Theme**: *EduTech AI - Intelligent Quality Education Access.*
* **Slide 2: The Core Problem**: General platforms provide one-size-fits-all videos. Underprivileged students get overwhelmed, while educators have zero visibility on learning risk levels.
* **Slide 3: Our Solution**: A stateless AI-powered digital mentor that maps weak areas on survey onboarding, builds 4-week roadmap timelines, offers 24/7 AI tutor guidance, and runs Random Forest ML models to predict grades and alert teachers of academic risk.
* **Slide 4: System Architecture**: Spring Boot security and FastAPI separation of concerns, backed by decrease-and-conquer resource index lookups.
* **Slide 5: Live Demo & Future Scope**: Expand visual search labs to other core CS paradigms and integrate multi-agent speech support.

### 2. Live Demo Script
1. **Landing Page**: Start at `http://localhost:3000`. Point out the glassmorphic dark-mode design. Click **"Fast-Track Student Demo"**.
2. **Onboarding**: Explain that the survey maps user characteristics. Click through Steps 1-4, select weaknesses like *"Algorithmic Complexity"*, and click **"Finalize"**.
3. **Student Dashboard**: Show the 4-week study timeline. Point out the **"Performance Prediction"** card which says "Risk: Low / B Grade" based on our Random Forest model. Show the smart recommended resources with matching reasons.
4. **AI Tutor Chat**: Open the sidebar tutor. Click *"Explain Binary Search complexity"*. Inspect the rich formatted markdown guide.
5. **Algorithmic Lab**: Open the lab. Select target value `42`. Click **Linear** (watch it scan sequentially). Then click **Binary** (watch decrease-and-conquer highlight bounds shrinking to the target in 3 steps). Click **Submit Answers** in the worksheet to show AI grading.
6. **Admin Dashboard**: Log out and click **"Fast-Track Admin Demo"**. Highlight classroom rosters, aggregated averages, and student performance risks.
